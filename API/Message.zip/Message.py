#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests


# In[10]:


url="https://dapi.p3p.repl.co/api/?currency=cad"

response=requests.get(url)
price=response.json()["key1"]["key2"]

example_good_price=6700

if price < example_good_price:
    def inform_me(price):
        API-KEY=''
        url1=f"https://api.kavenegar.com/v1/{API-KEY}/sms/send.json"
        pay_load={"receptor":'09111111111' , 'message': f"Hello the price is as low as  {price}"}
        response=requests.post(url1 , data=pay_load)
        print(response)

