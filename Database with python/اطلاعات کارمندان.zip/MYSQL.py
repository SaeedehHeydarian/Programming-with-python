#!/usr/bin/env python
# coding: utf-8

# In[53]:


import mysql.connecto

mydb = mysql.connector.connect(
    host="localhost",
    user="yourusername",
    password="yourpassword",
    database="yourdatabase"
)

mycursor=mydb.cursor()

query=("SELECT Name, Weight , Height FROM yourtable"
       "ORDER BY Height DESC , Weight ASC")

mycursor.execute(query)
mydb.commit()

for name , height , weight in mycursor:
    print(f"{name} {height} {weight}")
    
mycursor.close()
mydb.close()


# In[ ]:




