import mysql.connector
import re
def get_email():
    pattern = r'^\w+@[\w]+\.[\w]+$'
    
    while True:
        email = input()
        if re.match(pattern, email):
            return email
        else:
            print("Please insert a valid email format: expression@string.string")

def get_password():
    password = input()

    has_integer = False
    has_string = False
    
    for char in password:
        if char.isdigit():
            has_integer = True
        elif char.isalpha():
            has_string = True
    
    if has_integer and has_string:
        return password
    else:
        print("Password must contain both letters and digits.")
        return get_password()



def mycursor(email, password):
    mydb = mysql.connector.connect(
        host="your_host",
        user="your_user",
        password="your_password",
        database="your_database"
    )

    mycursor = mydb.cursor()
    mycursor.execute("CREATE TABLE mytable(email VARCHAR(50), password VARCHAR(50)")
    mydb.commit()


    query = "INSERT INTO mytable (email, password) VALUES (%s, %s)"
    values = (email, password)
    
    mycursor.execute(query, values)
    
    mydb.commit()
    mydb.close()

email=get_email()
password=get_password()
mycursor(email, password)