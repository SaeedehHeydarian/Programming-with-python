from django.shortcuts import render

from django.http import HttpResponse
from . import models

def index (request):
    ret='<body>'
    all_post=models.Post.objects.all()
    for post in all_post:
        ret=ret+ '<p>' + post.text +"<p>"
    ret=ret+ '<body>'

    return HttpResponse(ret)
# Create your views here.
