#!/usr/bin/env python
# coding: utf-8

# In[11]:


from datetime import datetime
import re


# In[19]:


date_birth=input()


# In[24]:


if re.search("\d{4}\/\d{2}\/\d{2}" , date_birth) and int(date_birth[5:7]) <13 and int(date_birth[8:11]) < 31:
    now=datetime.today()
    age= now.year - int(date_birth[0:4]) - ((now.month , now.day) < ((int(date_birth[5:7])) ,int(date_birth[8:11])) )
    print(age) 
else:
    print("WRONG")

