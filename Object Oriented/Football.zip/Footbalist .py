#!/usr/bin/env python
# coding: utf-8

# In[93]:


import random 

playesrs=["حسین" , "مازیار" , "اکبر" , "نیما" ,  "مهدی" , "فرهاد" , "محمد" , "خشایار" 
         , "میلاد" , "مصطفی" ,  "امین" , "سعید" , "پویا", "پوریا" , "رضا"
         , "علی" , "بهزاد" , "سهیل" , "بهروز" , "شهروز" , "سامان" , "محسن"]
player_obj=[]

class Human:
    def __init__(self , name):
        self.name=name
    
    
class Footbalist(Human):
     pass
 




for player in playesrs:
    bazikon=Footbalist(player)
    player_obj.append(bazikon)
    
    
    
random.shuffle(playesrs)
num_players=len(player_obj)//2
A= player_obj[num_players:]
B= player_obj[:num_players]

for player in A:
    print(f"{player.name} : A")

for player in B:
    print(f"{player.name} : B")


# In[ ]:





# In[ ]:




