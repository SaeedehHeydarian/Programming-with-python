#!/usr/bin/env python
# coding: utf-8

# In[4]:


import requests
from bs4 import BeautifulSoup
import mysql.connector
import re


# In[ ]:


elements="""<select required="" aria-label="Change vehicle make" class="form-select-element-challenger form-select-no-border form-select-no-label form-select-borderless" data-test="searchFiltersMake"><option value="">All</option><option value="acura">Acura</option><option value="alfa-romeo">Alfa Romeo</option><option value="am-general">AM General</option><option value="aston-martin">Aston Martin</option><option value="audi">Audi</option><option value="bentley">Bentley</option><option value="bmw">BMW</option><option value="buick">Buick</option><option value="cadillac">Cadillac</option><option value="chevrolet">Chevrolet</option><option value="chrysler">Chrysler</option><option value="dodge">Dodge</option><option value="eagle">Eagle</option><option value="ferrari">Ferrari</option><option value="fiat">FIAT</option><option value="fisker">Fisker</option><option value="ford">Ford</option><option value="freightliner">Freightliner</option><option value="genesis">Genesis</option><option value="geo">Geo</option><option value="gmc">GMC</option><option value="honda">Honda</option><option value="hummer">HUMMER</option><option value="hyundai">Hyundai</option><option value="infiniti">INFINITI</option><option value="isuzu">Isuzu</option><option value="jaguar">Jaguar</option><option value="jeep">Jeep</option><option value="karma">Karma</option><option value="kia">Kia</option><option value="lamborghini">Lamborghini</option><option value="land-rover">Land Rover</option><option value="lexus">Lexus</option><option value="lincoln">Lincoln</option><option value="lotus">Lotus</option><option value="lucid">Lucid</option><option value="maserati">Maserati</option><option value="maybach">Maybach</option><option value="mazda">Mazda</option><option value="mclaren">McLaren</option><option value="mercedes-benz">Mercedes-Benz</option><option value="mercury">Mercury</option><option value="mini">MINI</option><option value="mitsubishi">Mitsubishi</option><option value="nissan">Nissan</option><option value="oldsmobile">Oldsmobile</option><option value="plymouth">Plymouth</option><option value="polestar">Polestar</option><option value="pontiac">Pontiac</option><option value="porsche">Porsche</option><option value="ram">Ram</option><option value="rivian">Rivian</option><option value="rolls-royce">Rolls-Royce</option><option value="saab">Saab</option><option value="saturn">Saturn</option><option value="scion">Scion</option><option value="smart">smart</option><option value="subaru">Subaru</option><option value="suzuki">Suzuki</option><option value="tesla">Tesla</option><option value="toyota">Toyota</option><option value="volkswagen">Volkswagen</option><option value="volvo">Volvo</option></select>"""


# In[ ]:


list_of_cars=re.findall(r'value=\"(\w+)\">',elements )


# In[181]:


user_inetrested_car=input()


# In[183]:


if user_inetrested_car.lower() in list_of_cars:
    user_url= user_inetrested_car + "\\"
    url=("https://www.truecar.com/used-cars-for-sale/listings/" + user_url)
    r=requests.get(url + user_inetrested_car )
    print(r.status_code)


# In[184]:


soup=BeautifulSoup(r.content , "html.parser")
car_prices=soup.find_all("div" , attrs={"class":"vehicle-card-bottom-pricing-secondary pl-3 lg:pl-2 vehicle-card-bottom-max-50"})
list_price=[]
for price in car_prices:
    list_price.append(price.text)
performance_list=[]
performance_car=soup.find_all("div" , attrs={"class":"truncate text-xs"})
for p in performance_car:
    performance_list.append(p.text)


# In[185]:


new_list_performance=[]
for i in performance_list:
    if re.match("\d+.*miles", i):
        new_list_performance.append(i)
        


# In[186]:


mydb = mysql.connector.connect(
    host="your_host",
    user="your_user",
    password="your_password",
    database="your_database")

mycursor = mydb.cursor()
mycursor.execute("CREATE TABLE mytable(price VARCHAR(20), performance VARCHAR(20)")
mydb.commit()


for i ,(pric, perf) in enumerate(zip(list_price , new_list_performance)):
    if i < 20:
        query = "INSERT INTO mytable (price, performance) VALUES (%s, %s)"
        values = (pric, perf)
        mycursor.execute(query, values)
        mydb.commit()

mydb.close()  


# In[ ]:




