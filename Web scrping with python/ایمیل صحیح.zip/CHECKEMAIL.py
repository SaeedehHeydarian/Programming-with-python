#!/usr/bin/env python
# coding: utf-8

# In[12]:


import re


# In[37]:


email = input()


# In[38]:


if re.search(r".+\@.+\..+",email) == None:
    print("WRONG")
else:
    print("OK")


# In[ ]:




